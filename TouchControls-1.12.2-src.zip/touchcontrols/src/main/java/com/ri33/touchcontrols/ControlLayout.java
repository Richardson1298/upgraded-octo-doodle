package com.ri33.touchcontrols;

import net.minecraft.client.Minecraft;

/**
 * Хранит геометрию и состояние всех touch-элементов:
 * джойстик слева, 5 кнопок действий справа/снизу, зона свайпа камеры.
 */
public class ControlLayout {

    // ---- Джойстик ----
    public static final int JOYSTICK_MARGIN = 20;
    public static final int JOYSTICK_RADIUS = 45;   // внешний круг (база)
    public static final int JOYSTICK_KNOB_RADIUS = 20; // внутренний круг (стик)

    // Текущее состояние джойстика
    public static boolean joystickActive = false;
    public static int joystickPointerId = -1; // условный id "активного взаимодействия" (мышь = 0)
    public static float joystickDX = 0f; // -1..1
    public static float joystickDY = 0f; // -1..1
    public static int joystickCenterX, joystickCenterY;
    public static int joystickKnobX, joystickKnobY;

    // ---- Кнопки действий ----
    public static final int BUTTON_RADIUS = 32;
    public static final int BUTTON_MARGIN = 18;
    public static final int BUTTON_GAP = 14;

    public enum ActionButton {
        JUMP, USE, INVENTORY, SNEAK
    }

    // Прямоугольные хитбоксы кнопок пересчитываются каждый кадр под текущее разрешение
    public static int[] btnX = new int[ActionButton.values().length];
    public static int[] btnY = new int[ActionButton.values().length];
    public static boolean[] btnPressed = new boolean[ActionButton.values().length];

    public static void recalcLayout() {
        Minecraft mc = Minecraft.getMinecraft();
        int sw = mc.displayWidth;
        int sh = mc.displayHeight;
        // displayWidth/Height — в физических пикселях; для GUI-координат нужен scaled resolution,
        // но для зон касания (сырые координаты мыши) физические пиксели — то что нужно.

        joystickCenterX = JOYSTICK_MARGIN + JOYSTICK_RADIUS;
        joystickCenterY = sh - JOYSTICK_MARGIN - JOYSTICK_RADIUS;
        if (!joystickActive) {
            joystickKnobX = joystickCenterX;
            joystickKnobY = joystickCenterY;
        }

        // Кнопки — столбиком снизу-справа, снизу вверх: SNEAK, INVENTORY, USE, ATTACK, JUMP
        int x = sw - BUTTON_MARGIN - BUTTON_RADIUS;
        int y = sh - BUTTON_MARGIN - BUTTON_RADIUS;
        ActionButton[] order = { ActionButton.SNEAK, ActionButton.INVENTORY, ActionButton.USE, ActionButton.JUMP };
        for (ActionButton b : order) {
            btnX[b.ordinal()] = x;
            btnY[b.ordinal()] = y;
            y -= (BUTTON_RADIUS * 2 + BUTTON_GAP);
        }
    }

    /** Находится ли точка (px, py) в круге джойстика (зона активации/базы). */
    public static boolean isInJoystickZone(int px, int py) {
        // Зона захвата джойстика — увеличенная область в левом нижнем углу,
        // чтобы стик было легко "поймать" пальцем, а не только точно в центр.
        int zoneRadius = JOYSTICK_RADIUS * 2;
        int dx = px - joystickCenterX;
        int dy = py - joystickCenterY;
        return (dx * dx + dy * dy) <= (zoneRadius * zoneRadius);
    }

    /** Возвращает индекс кнопки под точкой или -1. */
    public static int getButtonAt(int px, int py) {
        for (ActionButton b : ActionButton.values()) {
            int i = b.ordinal();
            int dx = px - btnX[i];
            int dy = py - btnY[i];
            if (dx * dx + dy * dy <= BUTTON_RADIUS * BUTTON_RADIUS) {
                return i;
            }
        }
        return -1;
    }

    public static void resetJoystick() {
        joystickActive = false;
        joystickPointerId = -1;
        joystickDX = 0f;
        joystickDY = 0f;
        joystickKnobX = joystickCenterX;
        joystickKnobY = joystickCenterY;
    }
}
