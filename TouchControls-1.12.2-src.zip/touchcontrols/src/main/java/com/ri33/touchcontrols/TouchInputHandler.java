package com.ri33.touchcontrols;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

/**
 * Ловит сырой ввод мыши (которым PojavLauncher транслирует тач-касания)
 * и превращает его в поведение как в Bedrock:
 *  - джойстик слева -> ходьба (W/A/S/D)
 *  - свайп (протяжка) в остальной части экрана -> вращение камеры
 *  - короткий тап без движения в зоне камеры -> удар/атака (как тап по цели в Bedrock)
 *  - 4 кнопки действий: Прыжок, Взаимодействие (ПКМ), Инвентарь, Присесть
 *
 * PojavLauncher транслирует одно касание в события мыши, поэтому одновременно
 * обрабатывается максимум одна активная точка взаимодействия.
 */
public class TouchInputHandler {

    public static void init() {
    }

    // Состояние "перетаскивания" для свайпа камеры / определения тапа
    private static boolean dragActive = false;
    private static int dragStartX = 0;
    private static int dragStartY = 0;
    private static int lastMouseX = 0;
    private static int lastMouseY = 0;
    private static boolean dragMoved = false; // стал ли drag "настоящим" свайпом (сдвиг больше порога)
    private static boolean attackFiredThisPress = false;

    private static final int TAP_MOVE_THRESHOLD = 6; // пикселей — если сдвиг меньше, это тап, а не свайп
    private static final float CAMERA_SENSITIVITY = 0.35f;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.currentScreen != null) {
            resetAllInputs();
            return;
        }

        ControlLayout.recalcLayout();
        pollMouse(mc);
        applyJoystickMovement(mc);
    }

    private void pollMouse(Minecraft mc) {
        boolean down = Mouse.isButtonDown(0); // ЛКМ = активное касание
        int mx = Mouse.getX();
        int my = mc.displayHeight - Mouse.getY(); // конвертация в экранные координаты (Y сверху вниз)

        if (down) {
            if (!ControlLayout.joystickActive && !dragActive) {
                // Новое нажатие — определяем: кнопка, джойстик или начало драга/тапа камеры
                int btn = ControlLayout.getButtonAt(mx, my);
                if (btn >= 0) {
                    pressButton(btn);
                } else if (ControlLayout.isInJoystickZone(mx, my)) {
                    ControlLayout.joystickActive = true;
                    ControlLayout.joystickPointerId = 0;
                    updateJoystickKnob(mx, my);
                } else {
                    dragActive = true;
                    dragMoved = false;
                    attackFiredThisPress = false;
                    dragStartX = mx;
                    dragStartY = my;
                    lastMouseX = mx;
                    lastMouseY = my;
                }
            } else if (ControlLayout.joystickActive) {
                updateJoystickKnob(mx, my);
            } else if (dragActive) {
                int dx = mx - lastMouseX;
                int dy = my - lastMouseY;
                int totalDx = mx - dragStartX;
                int totalDy = my - dragStartY;

                if (!dragMoved && (totalDx * totalDx + totalDy * totalDy) > TAP_MOVE_THRESHOLD * TAP_MOVE_THRESHOLD) {
                    dragMoved = true; // превратилось в настоящий свайп камеры
                }

                if (dragMoved && (dx != 0 || dy != 0)) {
                    rotateCamera(mc, dx, dy);
                }
                lastMouseX = mx;
                lastMouseY = my;
            }
        } else {
            if (ControlLayout.joystickActive) {
                ControlLayout.resetJoystick();
            }
            if (dragActive && !dragMoved && !attackFiredThisPress) {
                // Палец отпущен без сдвига -> это был тап по экрану = атака, как в Bedrock
                triggerAttackClick(mc);
            }
            dragActive = false;
            dragMoved = false;
            attackFiredThisPress = false;
            releaseAllButtons();
        }
    }

    private void updateJoystickKnob(int mx, int my) {
        int dx = mx - ControlLayout.joystickCenterX;
        int dy = my - ControlLayout.joystickCenterY;
        double dist = Math.sqrt(dx * dx + dy * dy);
        double maxDist = ControlLayout.JOYSTICK_RADIUS;

        if (dist > maxDist) {
            double scale = maxDist / dist;
            dx = (int) (dx * scale);
            dy = (int) (dy * scale);
            dist = maxDist;
        }

        ControlLayout.joystickKnobX = ControlLayout.joystickCenterX + dx;
        ControlLayout.joystickKnobY = ControlLayout.joystickCenterY + dy;

        float nx = (float) (dx / maxDist);
        float ny = (float) (dy / maxDist);
        float deadZone = 0.15f;
        if (Math.abs(nx) < deadZone) nx = 0;
        if (Math.abs(ny) < deadZone) ny = 0;

        ControlLayout.joystickDX = nx;
        ControlLayout.joystickDY = ny;
    }

    private void applyJoystickMovement(Minecraft mc) {
        GameSettings s = mc.gameSettings;
        float dx = ControlLayout.joystickDX;
        float dy = ControlLayout.joystickDY;

        boolean forward = dy < -0.15f;
        boolean back = dy > 0.15f;
        boolean left = dx < -0.15f;
        boolean right = dx > 0.15f;

        setKeyState(s.keyBindForward, forward);
        setKeyState(s.keyBindBack, back);
        setKeyState(s.keyBindLeft, left);
        setKeyState(s.keyBindRight, right);
    }

    private void rotateCamera(Minecraft mc, int dxPixels, int dyPixels) {
        EntityPlayerSP p = mc.player;
        if (p == null) return;
        float yaw = p.rotationYaw + dxPixels * CAMERA_SENSITIVITY;
        float pitch = p.rotationPitch - dyPixels * CAMERA_SENSITIVITY;
        pitch = Math.max(-90f, Math.min(90f, pitch));
        p.setPositionAndRotation(p.posX, p.posY, p.posZ, yaw, pitch);
    }

    /**
     * Короткий тап по зоне камеры = удар/атака по цели под курсором,
     * как обычный клик ЛКМ в ванильном Minecraft (используем стандартный клик-обработчик игры).
     */
    private void triggerAttackClick(Minecraft mc) {
        if (mc.player == null || mc.objectMouseOver == null) return;
        attackFiredThisPress = true;
        // Эмулируем одно "мгновенное" нажатие ЛКМ через штатный KeyBinding —
        // клиент Minecraft сам обработает это как обычный клик атаки в своём игровом цикле ввода.
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), true);
        KeyBinding.onTick(mc.gameSettings.keyBindAttack.getKeyCode());
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
    }

    private void pressButton(int index) {
        ControlLayout.btnPressed[index] = true;
        Minecraft mc = Minecraft.getMinecraft();
        GameSettings s = mc.gameSettings;
        ControlLayout.ActionButton b = ControlLayout.ActionButton.values()[index];
        switch (b) {
            case JUMP:
                setKeyState(s.keyBindJump, true);
                break;
            case USE:
                setKeyState(s.keyBindUseItem, true);
                break;
            case SNEAK:
                setKeyState(s.keyBindSneak, true);
                break;
            case INVENTORY:
                if (mc.currentScreen == null && mc.player != null) {
                    mc.displayGuiScreen(new net.minecraft.client.gui.inventory.GuiInventory(mc.player));
                }
                break;
        }
    }

    private void releaseAllButtons() {
        Minecraft mc = Minecraft.getMinecraft();
        GameSettings s = mc.gameSettings;
        for (int i = 0; i < ControlLayout.btnPressed.length; i++) {
            ControlLayout.btnPressed[i] = false;
        }
        setKeyState(s.keyBindJump, false);
        setKeyState(s.keyBindUseItem, false);
        setKeyState(s.keyBindSneak, false);
    }

    private void resetAllInputs() {
        ControlLayout.resetJoystick();
        dragActive = false;
        dragMoved = false;
        attackFiredThisPress = false;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings != null) {
            GameSettings s = mc.gameSettings;
            setKeyState(s.keyBindForward, false);
            setKeyState(s.keyBindBack, false);
            setKeyState(s.keyBindLeft, false);
            setKeyState(s.keyBindRight, false);
            setKeyState(s.keyBindJump, false);
            setKeyState(s.keyBindUseItem, false);
            setKeyState(s.keyBindSneak, false);
        }
    }

    private void setKeyState(KeyBinding key, boolean pressed) {
        KeyBinding.setKeyBindState(key.getKeyCode(), pressed);
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        // Физическая клавиатура (если подключена) продолжает работать как обычно.
    }
}
