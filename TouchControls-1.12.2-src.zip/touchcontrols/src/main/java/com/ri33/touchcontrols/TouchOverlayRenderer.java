package com.ri33.touchcontrols;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Рисует Bedrock-style джойстик и кнопки поверх игрового экрана, используя
 * готовые PNG-текстуры (assets/touchcontrols/textures/gui/) вместо
 * геометрических примитивов — плоские белые иконки на тёмной полупрозрачной
 * подложке, как в оригинальном мобильном интерфейсе Minecraft.
 */
public class TouchOverlayRenderer {

    private static final String NS = "touchcontrols";

    private static final ResourceLocation JOYSTICK_BASE = new ResourceLocation(NS, "textures/gui/joystick_base.png");
    private static final ResourceLocation JOYSTICK_KNOB = new ResourceLocation(NS, "textures/gui/joystick_knob.png");

    private static final ResourceLocation BTN_JUMP = new ResourceLocation(NS, "textures/gui/btn_jump.png");
    private static final ResourceLocation BTN_JUMP_P = new ResourceLocation(NS, "textures/gui/btn_jump_pressed.png");
    private static final ResourceLocation BTN_USE = new ResourceLocation(NS, "textures/gui/btn_use.png");
    private static final ResourceLocation BTN_USE_P = new ResourceLocation(NS, "textures/gui/btn_use_pressed.png");
    private static final ResourceLocation BTN_INV = new ResourceLocation(NS, "textures/gui/btn_inventory.png");
    private static final ResourceLocation BTN_INV_P = new ResourceLocation(NS, "textures/gui/btn_inventory_pressed.png");
    private static final ResourceLocation BTN_SNEAK = new ResourceLocation(NS, "textures/gui/btn_sneak.png");
    private static final ResourceLocation BTN_SNEAK_P = new ResourceLocation(NS, "textures/gui/btn_sneak_pressed.png");

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.currentScreen != null) return;

        ScaledResolution sr = new ScaledResolution(mc);
        float scaleX = (float) sr.getScaledWidth() / mc.displayWidth;
        float scaleY = (float) sr.getScaledHeight() / mc.displayHeight;

        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0); // SRC_ALPHA, ONE_MINUS_SRC_ALPHA
        GlStateManager.color(1f, 1f, 1f, 1f);

        drawJoystick(mc, scaleX, scaleY);
        drawButtons(mc, scaleX, scaleY);

        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private void drawJoystick(Minecraft mc, float scaleX, float scaleY) {
        float baseSize = ControlLayout.JOYSTICK_RADIUS * 2 * scaleX;
        float cx = ControlLayout.joystickCenterX * scaleX;
        float cy = ControlLayout.joystickCenterY * scaleY;
        drawTexturedQuad(mc, JOYSTICK_BASE, cx - baseSize / 2f, cy - baseSize / 2f, baseSize, baseSize);

        float knobSize = ControlLayout.JOYSTICK_KNOB_RADIUS * 2 * scaleX;
        float kx = ControlLayout.joystickKnobX * scaleX;
        float ky = ControlLayout.joystickKnobY * scaleY;
        drawTexturedQuad(mc, JOYSTICK_KNOB, kx - knobSize / 2f, ky - knobSize / 2f, knobSize, knobSize);
    }

    private void drawButtons(Minecraft mc, float scaleX, float scaleY) {
        for (ControlLayout.ActionButton b : ControlLayout.ActionButton.values()) {
            int i = b.ordinal();
            float size = ControlLayout.BUTTON_RADIUS * 2 * scaleX;
            float x = ControlLayout.btnX[i] * scaleX - size / 2f;
            float y = ControlLayout.btnY[i] * scaleY - size / 2f;
            boolean pressed = ControlLayout.btnPressed[i];

            ResourceLocation tex = textureFor(b, pressed);
            drawTexturedQuad(mc, tex, x, y, size, size);
        }
    }

    private ResourceLocation textureFor(ControlLayout.ActionButton b, boolean pressed) {
        switch (b) {
            case JUMP: return pressed ? BTN_JUMP_P : BTN_JUMP;
            case USE: return pressed ? BTN_USE_P : BTN_USE;
            case INVENTORY: return pressed ? BTN_INV_P : BTN_INV;
            case SNEAK: return pressed ? BTN_SNEAK_P : BTN_SNEAK;
            default: return BTN_JUMP;
        }
    }

    private void drawTexturedQuad(Minecraft mc, ResourceLocation tex, float x, float y, float w, float h) {
        mc.getTextureManager().bindTexture(tex);
        GlStateManager.enableTexture2D();

        net.minecraft.client.renderer.BufferBuilder buf = net.minecraft.client.renderer.Tessellator.getInstance().getBuffer();
        buf.begin(7, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION_TEX);
        buf.pos(x, y + h, 0).tex(0, 1).endVertex();
        buf.pos(x + w, y + h, 0).tex(1, 1).endVertex();
        buf.pos(x + w, y, 0).tex(1, 0).endVertex();
        buf.pos(x, y, 0).tex(0, 0).endVertex();
        net.minecraft.client.renderer.Tessellator.getInstance().draw();
    }
}
