package com.ri33.touchcontrols;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = TouchControlsMod.MODID, name = TouchControlsMod.NAME, version = TouchControlsMod.VERSION, clientSideOnly = true)
public class TouchControlsMod {

    public static final String MODID = "touchcontrols";
    public static final String NAME = "Touch Controls";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static TouchControlsMod instance;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        TouchInputHandler.init();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new TouchOverlayRenderer());
        MinecraftForge.EVENT_BUS.register(new TouchInputHandler());
    }
}
